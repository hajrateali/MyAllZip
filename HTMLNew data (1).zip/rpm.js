//_________YE DRILL KA RPM NIKALNE KE HAI________//
const rpmbox = {
  c: document.querySelector(".c"),
  d: document.querySelector(".d"),
  b: document.querySelector(".b"),
  
};
function drillrpm() {
  c.hidden = true;
  d.hidden = false;
}
function chekrpm() {
  let rpm = parseFloat(document.getElementById("asd").value);
  let rpmprint = (4777 / rpm)
  document.getElementById("abc").innerText = rpmprint;
}
//_____________________________________________//


// ______YE MUVIE SITE KE LIYE HAI______//

function muvie() {
  let muvies = document.querySelector(".muvie");
  b.hidden = true;
  muvies.hidden = false;
}
 //-----------------------------------------//
 
 