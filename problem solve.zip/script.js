function uploadImage() {
  const input = document.getElementById('imageInput');
  const gallery = document.getElementById('gallery');
  const files = input.files;

  if (files.length === 0) {
    alert("Please select images.");
    return;
  }

  const images = [];
  let loaded = 0;

  for (let i = 0; i < files.length; i++) {
    const reader = new FileReader();

    reader.onload = function (e) {
      const imageUrl = e.target.result;
      images.push({ url: imageUrl });

      const img = document.createElement('img');
      img.src = imageUrl;
      img.style.width = "200px";
      img.style.margin = "10px";
      gallery.appendChild(img);

      loaded++;
      if (loaded === files.length) {
        // Sab image load ho gaye, ab JSON file banao
        const json = JSON.stringify({ images: images }, null, 2);
        downloadJSON(json, "images.json");
      }
    };

    reader.readAsDataURL(files[i]);
  }
}

function downloadJSON(data, filename) {
  const blob = new Blob([data], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();

  URL.revokeObjectURL(url);
}