function btn() {
  const name = document.querySelector(".name").value;
  const email = document.querySelector(".email").value;
  const pass = document.querySelector(".pass").value;
  
  const user = {
    name: name,
    email: email,
    password: pass
  };
  
  const jsonData = JSON.stringify(user);
  
  // Ab backend server ko data bhej rahe hain
  fetch('http://localhost:3000/save', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: jsonData
    })
    .then(res => res.text())
    .then(data => {
      alert('Data saved successfully!');
    })
    .catch(err => {
      alert('Error saving data.');
    });
}