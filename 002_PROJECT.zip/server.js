const express = require('express');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Save data to data.json
app.post('/save', (req, res) => {
  const newData = req.body;

  // Read old data
  fs.readFile('data.json', 'utf8', (err, data) => {
    let jsonArray = [];

    if (!err && data) {
      try {
        jsonArray = JSON.parse(data);
      } catch (e) {
        jsonArray = [];
      }
    }

    jsonArray.push(newData);

    fs.writeFile('data.json', JSON.stringify(jsonArray, null, 2), err => {
      if (err) {
        res.status(500).send('Failed to save data');
      } else {
        res.send('Data saved successfully');
      }
    });
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});