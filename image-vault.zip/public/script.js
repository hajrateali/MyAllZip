const form = document.getElementById('uploadForm');
const gallery = document.getElementById('gallery');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(form);
  const res = await fetch('/upload', {
    method: 'POST',
    body: formData
  });
  if (res.ok) {
    alert('Uploaded!');
    form.reset();
    loadImages();
  }
});

async function loadImages() {
  gallery.innerHTML = '';
  const res = await fetch('/images');
  const images = await res.json();
  images.forEach(img => {
    const link = document.createElement('a');
    link.href = `/image/${img.id}`;
    link.innerText = `Download ${img.name}`;
    link.download = img.name;
    gallery.appendChild(link);
    gallery.appendChild(document.createElement('br'));
  });
}

loadImages();
