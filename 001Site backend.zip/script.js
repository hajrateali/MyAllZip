document.getElementById('uploadForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  const formData = new FormData(this);

  const res = await fetch('/upload', {
    method: 'POST',
    body: formData
  });

  const data = await res.json();
  alert('File uploaded successfully!');
  loadGallery();
});

async function loadGallery() {
  const res = await fetch('/all');
  const files = await res.json();

  const gallery = document.getElementById('gallery');
  gallery.innerHTML = '';

  files.forEach(file => {
    if (file.type.startsWith('image/')) {
      const img = document.createElement('img');
      img.src = file.path;
      gallery.appendChild(img);
    }
  });
}

loadGallery();