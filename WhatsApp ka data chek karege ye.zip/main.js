let uploadedData = null;

document.getElementById('uploadJson').addEventListener('change', function(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(e) {
    try {
      uploadedData = JSON.parse(e.target.result);
      alert("JSON file loaded. Click 'Load' to display messages.");
    } catch (error) {
      alert("Invalid JSON file!");
    }
  };
  reader.readAsText(file);
});

function loadBtn() {
  if (!uploadedData) {
    alert("Please upload a JSON file first.");
    return;
  }
  displayMessages(uploadedData);
}

function displayMessages(data) {
  const chatBox = document.getElementById('chatBox');
  chatBox.innerHTML = ''; // Clear previous messages

  data.forEach(item => {
    const msgDiv = document.createElement('div');
    msgDiv.className = (item.sender.toLowerCase() === 'shama') ? 'shama' : 'ali';

    msgDiv.innerHTML = `
      ${item.message}
      <div class="time">${item.date} ${item.time}</div>
    `;

    chatBox.appendChild(msgDiv);
  });
}