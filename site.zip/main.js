const token = "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";

// ------ NEW REPO BANANE KE LIYE -------- //
let new1 = document.querySelector('.new');
new1.addEventListener('click', newrepo);

function newrepo() {
  let repoName = prompt("Naye repository ka naam daaliye:");
  if (!repoName) return;

  fetch('https://api.github.com/user/repos', {
    method: 'POST',
    headers: {
      Authorization: `token ${token}`,
      Accept: 'application/vnd.github+json',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: repoName,
      description: "Created from my GitHub UI",
      private: false // public repo banega
    })
  })
    .then(res => res.json())
    .then(data => {
      if (data.full_name) {
        alert("Repository bana diya gaya: " + data.full_name);
      } else if (data.message) {
        alert("Error: " + data.message);
      } else {
        alert("Kuch galat hua.");
      }
    })
    .catch(err => {
      alert("Network error: " + err.message);
    });
}

let all = document.querySelector('.all');
all.addEventListener('click', allrepo);

function allrepo() {
  let imgb = document.querySelector(".imgb");
  imgb.innerHTML = ""; // purana content hatao

  let hh = document.createElement("h3");
  hh.innerText = "ALL REPO";
  imgb.appendChild(hh);

  fetch('https://api.github.com/user/repos', {
    headers: {
      Authorization: `token ${token}`
    }
  })
    .then(rec => rec.json())
    .then(data => {
      data.forEach(file => {
        let repoName = file.name; // Yahan pe repo name safe rakha
        let alldiv = document.createElement('div');
        alldiv.className = repoName;
        alldiv.textContent = "📁 " + repoName;
        imgb.appendChild(alldiv);

        // Click par proper name ke saath function call
        alldiv.addEventListener('click', () => {
          showFilesInRepo(repoName);
        });
      });
    });
}

function showFilesInRepo(repoName, path = "") {
  let imgb = document.querySelector(".imgb");
  imgb.innerHTML = ""; // Clear

  let hh = document.createElement("h3");
  hh.innerText = `Files in ${repoName}${path ? '/' + path : ''}`;
  imgb.appendChild(hh);

  const url = `https://api.github.com/repos/shamaali86055/${repoName}/contents/${path}`;
  
  fetch(url, {
    headers: {
      Authorization: `token ${token}`
    }
  })
    .then(res => {
      if (!res.ok) throw new Error(`Error: ${res.status}`);
      return res.json();
    })
    .then(files => {
      files.forEach(f => {
        let fileDiv = document.createElement("div");
        fileDiv.className = "namer";
        fileDiv.textContent = (f.type === "dir" ? "📁 " : "📄 ") + f.name;
        imgb.appendChild(fileDiv);

        // Agar folder hai to us par click se andar ja sakein
        if (f.type === "dir") {
          fileDiv.addEventListener("click", () => {
            showFilesInRepo(repoName, path ? `${path}/${f.name}` : f.name);
          });
        }
      });
    })
    .catch(err => {
      let errorDiv = document.createElement("div");
      errorDiv.textContent = "Failed to load files: " + err.message;
      errorDiv.style.color = "red";
      imgb.appendChild(errorDiv);
    });
}

// ------ PROFILE DEKHNE KE LIYE -------- //
let your = document.querySelector('.your');
your.addEventListener('click', yourProfile);

function yourProfile() {
  let imgb = document.querySelector(".imgb");
  imgb.innerHTML = ""; 
  fetch('https://api.github.com/user', {
    headers: {
      Authorization: `token ${token}`
    }
  })
    .then(res => res.json())
    .then(user => {
      let hh = document.createElement("h3");
      hh.innerText = "YOUR PROFILE";
      imgb.appendChild(hh);
      // Ek wrapper div jisme sab kuch hoga
      let profileDiv = document.createElement("div");
      profileDiv.className = "profile-box";
      // Avatar (photo)
      let avatar = document.createElement("img");
      avatar.src = user.avatar_url;
      profileDiv.appendChild(avatar);
      // Info (naam, username, email)
      let name = document.createElement("div");
      name.textContent = "Name: " + (user.name || "Not Available");
      let username = document.createElement("div");
      username.textContent = "Username: " + user.login;
      let email = document.createElement("div");
      email.textContent = "Email: " + (user.email || "Not Public");
      profileDiv.appendChild(name);
      profileDiv.appendChild(username);
      profileDiv.appendChild(email);
      imgb.appendChild(profileDiv); // wrapper ko add karo
    });
}