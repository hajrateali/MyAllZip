const token = "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";
//-------------------------------------------//
let url = {};
let upload = {};
let username = "";
let repoName = "";
let pathName = ""; 
//-------------------------------------------//
const all = document.querySelector(".all");
all.addEventListener('click', allimg1)
function allimg1() {
  document.querySelector(".show").innerHTML = "";
  fetch('https://api.github.com/user/repos', {
      headers: {
        Authorization: `token ${token}`
      }
    })
    .then(res => res.json())
    .then(dat1 => {
      dat1.forEach(file => {
        username = file.owner.login;
        repoName = file.name;
        url[file.name] = `https://api.github.com/repos/${username}/${repoName}/contents/${pathName}`;
        let repoDiv = document.createElement("div");
        repoDiv.innerText = "📁 " + file.name;
        repoDiv.addEventListener('click', () => {repofile(file.name);})
        repoDiv.className = "clrepo";
        document.querySelector(".show").appendChild(repoDiv);
      });
    });
}

function repofile(name) {
  fetch(url[name], {
    headers: {
    Authorization: `token ${token}`
    }
  })
  .then(r => r.json())
  .then(data => {
    let show = document.querySelector(".show");
    show.innerHTML = "";
    data.forEach(f => {
    upload[f.name] = f.download_url;
    let refile = document.createElement("div");
    refile.innerText = "📄 " + f.name;
    refile.addEventListener('click', () => {clickFile(f.name);})
    document.querySelector(".show").appendChild(refile);
  })})
}

function clickFile(name) {
  fetch(upload[name])
    .then(r => r.text())
    .then(t => {
    document.querySelector(".show").innerHTML = "";
    const textarea = document.createElement("textarea");
    textarea.value = t;
    document.querySelector(".show").appendChild(textarea);
    });
}
