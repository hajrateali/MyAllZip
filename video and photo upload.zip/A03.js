const token = "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"; // apna token
const username = "hajrateali";
const repo = "Private";
const jsonFile = "image.json";
const branch = "main";

document.querySelector(".new").addEventListener("click", () => {
  document.getElementById("photoInput").click();
});

document.getElementById("photoInput").addEventListener("change", function () {
  const files = this.files;
  const imgbDiv = document.querySelector(".imgb");

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const filename = file.name;

    const reader = new FileReader();
    reader.onload = function () {
      const base64Image = reader.result;

      fetch(`https://api.github.com/repos/${username}/${repo}/contents/${jsonFile}`, {
        headers: {
          Authorization: `token ${token}`
        }
      })
      .then(res => res.json())
      .then(jsonFileData => {
        const oldContent = atob(jsonFileData.content);
        let data = [];
        try {
          data = JSON.parse(oldContent);
        } catch (e) {}

        data.push({
          name: filename,
          base64: base64Image
        });

        fetch(`https://api.github.com/repos/${username}/${repo}/contents/${jsonFile}`, {
          method: "PUT",
          headers: {
            Authorization: `token ${token}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            message: `Add image ${filename}`,
            content: btoa(JSON.stringify(data, null, 2)),
            sha: jsonFileData.sha,
            branch: branch
          })
        });

        const img = document.createElement("img");
        img.src = base64Image;
        img.style.width = "95%";
        img.style.marginTop = "10px";
        imgbDiv.appendChild(img);
      });
    };
    reader.readAsDataURL(file);
  }
});