const token = "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"; // Apna token daalo
const username = "hajrateali";
const repo = "Private";
const jsonFile = "Videos.json";
const branch = "main";

window.addEventListener("DOMContentLoaded", () => {
  document.querySelector(".newvideo").addEventListener("click", () => {
    document.getElementById("videoInput").click();
  });

  document.getElementById("videoInput").addEventListener("change", function () {
    const files = this.files;
    const imgbDiv = document.querySelector(".show");

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const filename = file.name;

      const reader = new FileReader();
      reader.onload = function () {
        const base64Video = reader.result;

        fetch(`https://api.github.com/repos/${username}/${repo}/contents/${jsonFile}`, {
          headers: {
            Authorization: `token ${token}`
          }
        })
        .then(res => res.json())
        .then(jsonFileData => {
          const oldContent = atob(jsonFileData.content);
          let data = [];
          try {
            data = JSON.parse(oldContent);
          } catch (e) {}

          data.push({
            name: filename,
            base64: base64Video
          });

          fetch(`https://api.github.com/repos/${username}/${repo}/contents/${jsonFile}`, {
            method: "PUT",
            headers: {
              Authorization: `token ${token}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              message: `Add video ${filename}`,
              content: btoa(JSON.stringify(data, null, 2)),
              sha: jsonFileData.sha,
              branch: branch
            })
          });

          const video = document.createElement("video");
          video.src = base64Video;
          video.controls = true;
          video.style.width = "95%";
          video.style.maxHeight = "300px";
          video.style.marginTop = "10px";
          imgbDiv.appendChild(video);
        });
      };
      reader.readAsDataURL(file);
    }
  });
});