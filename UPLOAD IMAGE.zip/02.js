
//------------------------------------------//
let all = document.querySelector('.all');
all.addEventListener('click', allpic);

function allpic() {
  console.log("Function called");
  fetch('https://raw.githubusercontent.com/hajrateali/newrepo/main/data.json')
    .then(res => res.json())
    .then(data => {
      data.forEach(image => {
        //console.log(image.image);
        const img = new Image();
        img.src = image.image;
        document.querySelector(".imgb").appendChild(img);
      });
    });
}



