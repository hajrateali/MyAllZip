const token = "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";
//------------------------------------------//
const new1 = document.querySelector(".new");
new1.addEventListener('click', newadd);

function newadd() {
  let imgb = document.querySelector(".imgb");
  let fill = document.createElement("input");
  fill.type = "file";
  fill.className = "fill";
  fill.multiple = true;

  let imageArray = [];

  fill.addEventListener('change', function () {
    let files = fill.files;
    for (let i = 0; i < files.length; i++) {
      let file = files[i];
      if (file.type.startsWith("image/")) {
        let reader = new FileReader();
        reader.onload = function (e) {
          let dataURL = e.target.result;
          imageArray.push({ image: dataURL });

          let img = document.createElement("img");
          img.src = dataURL;
          imgb.appendChild(img);
        };
        reader.readAsDataURL(file);
      } else {
        alert("File " + file.name + " is not an image.");
      }
    }
  });

  let uploadBtn = document.createElement("button");
  uploadBtn.textContent = "Upload to GitHub";
  uploadBtn.style.display = "block";
  uploadBtn.style.margin = "10px";
  uploadBtn.onclick = () => uploadToGitHub(imageArray);
  document.querySelector(".bb").appendChild(fill);
  document.querySelector(".bb").appendChild(uploadBtn);
}

function uploadToGitHub(newArray) {
  const repo = 'newrepo';
  const owner = 'hajrateali';
  const path = 'data.json';
  const apiUrl = `https://api.github.com/repos/${owner}/${repo}/contents/${path}`;

  fetch(apiUrl, {
    headers: {
      Authorization: `token ${token}`
    }
  })
    .then(res => res.json())
    .then(data => {
      const sha = data.sha;
      const existingContent = JSON.parse(atob(data.content));
      const mergedContent = existingContent.concat(newArray);
      const encodedContent = btoa(unescape(encodeURIComponent(JSON.stringify(mergedContent, null, 2))));

      const body = {
        message: "Append new images",
        content: encodedContent,
        committer: {
          name: "Uploader",
          email: "uploader@example.com"
        },
        sha: sha
      };

      return fetch(apiUrl, {
        method: "PUT",
        headers: {
          Authorization: `token ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
      });
    })
    .then(res => res.json())
    .then(data => {
      alert("Images uploaded to GitHub!");
      console.log(data);
    })
    .catch(err => {
      // Agar file nahi mili toh naya file banaye
      const encodedContent = btoa(unescape(encodeURIComponent(JSON.stringify(newArray, null, 2))));
      const body = {
        message: "Create data.json",
        content: encodedContent,
        committer: {
          name: "Uploader",
          email: "uploader@example.com"
        }
      };
      fetch(apiUrl, {
        method: "PUT",
        headers: {
          Authorization: `token ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify(body)
      })
        .then(res => res.json())
        .then(data => {
          alert("File created on GitHub!");
          console.log(data);
        })
        .catch(err => {
          alert("Upload failed!");
          console.error(err);
        });
    });
}

