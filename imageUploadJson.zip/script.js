
async function upload() {
  const files = document.querySelector('.upload-img input').files;
  if (files.length === 0) return alert("Please select at least one image");

  let newImages = [];
  for (let file of files) {
    const base64 = await toBase64(file);
    newImages.push({ url: base64 });
  }

  const repo = "Shamaali86055/DataStore";
  const path = "02.json";
  const token = "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";

  let sha = null;
  let oldImages = [];

  try {
    const res = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
      headers: {
        "Authorization": `token ${token}`,
        "Accept": "application/vnd.github+json"
      }
    });
    const data = await res.json();
    sha = data.sha;

    // Decode old content
    const decoded = decodeURIComponent(escape(atob(data.content)));
    const json = JSON.parse(decoded);
    oldImages = json.images || [];

  } catch (e) {
    console.log("New file will be created.");
  }

  const finalImages = oldImages.concat(newImages); // Purane + naye

  const jsonData = JSON.stringify({ images: finalImages }, null, 2);
  const encodedData = btoa(unescape(encodeURIComponent(jsonData)));

  const res = await fetch(`https://api.github.com/repos/${repo}/contents/${path}`, {
    method: "PUT",
    headers: {
      "Authorization": `token ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      message: "Image upload from web",
      content: encodedData,
      sha: sha
    })
  });

  if (res.ok) {
    alert("Upload successful!");
    showImages(finalImages); // Sabhi image dikhao
  } else {
    alert("Upload failed!");
    console.error(await res.text());
  }
}