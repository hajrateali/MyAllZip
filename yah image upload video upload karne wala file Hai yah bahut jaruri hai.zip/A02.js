const token = "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"; // Apna token daalo
const username = "hajrateali";
const repo = "Private";
const jsonFile = "Videos.json";
const branch = "main";

document.querySelector(".newvideo").addEventListener("click", () => {
  document.getElementById("videoInput").click();
});

document.getElementById("videoInput").addEventListener("change", function () {
  const files = this.files;
  const imgbDiv = document.querySelector(".show");

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const filename = file.name;

    const reader = new FileReader();
    reader.onload = function () {
      const base64Video = reader.result;

      // Step 1: Get current Videos.json
      fetch(`https://api.github.com/repos/${username}/${repo}/contents/${jsonFile}`, {
        headers: {
          Authorization: `token ${token}`
        }
      })
      .then(res => res.json())
      .then(jsonFileData => {
        const oldContent = atob(jsonFileData.content);
        let data = [];
        try {
          data = JSON.parse(oldContent);
        } catch (e) {}

        // Step 2: Add new video data
        data.push({
          name: filename,
          base64: base64Video
        });

        // Step 3: Push updated JSON
        fetch(`https://api.github.com/repos/${username}/${repo}/contents/${jsonFile}`, {
          method: "PUT",
          headers: {
            Authorization: `token ${token}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            message: `Add video ${filename}`,
            content: btoa(JSON.stringify(data, null, 2)),
            sha: jsonFileData.sha,
            branch: branch
          })
        });

        // Step 4: Show preview
        const video = document.createElement("video");
        video.src = base64Video;
        video.controls = true;
        video.style.width = "95%";
        video.style.maxHeight = "300px";
        video.style.marginTop = "10px";
        imgbDiv.appendChild(video);
      });
    };
    reader.readAsDataURL(file);
  }
});