
const menuBtn = document.querySelector('.left');
const slider = document.querySelector('.slider1');
const body = document.querySelector('body');
menuBtn.addEventListener('click', function (e) {
  e.stopPropagation();
  slider.classList.toggle('active');
});
body.addEventListener('click', function (ali) {
  slider.classList.remove('active');
});
