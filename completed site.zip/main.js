const token = "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"
let new1 = document.querySelector('.new');
new1.addEventListener('click', allrepo);

function allrepo() {
  fetch('https://api.github.com/repos/Shamaali86055/PicAl/contents', {})
    .then(rec => rec.json())
    .then(data => {
      data.forEach(file => {
        if (file.type === "file" && /\.(jpe?g|png|gif|webp|bmp|svg)$/i.test(file.name)) {
          let img = document.createElement('img');
          let imgb = document.querySelector('.imgb');
          img.src = file.download_url;
          imgb.appendChild(img);
        }
        console.log(file.name);
      });
    });
}

