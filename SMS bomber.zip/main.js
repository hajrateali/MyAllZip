function bombit() {
  const mobile = document.getElementById('mobile').value.trim();
  const quantity = parseInt(document.getElementById('quantity').value);
  const timing = parseFloat(document.getElementById('timing').value);
  const status = document.getElementById('status');
  
  if (!mobile || isNaN(quantity) || isNaN(timing)) {
    status.textContent = "Sab fields bharo.";
    return;
  }
  
  if (timing < 1.5 || timing > 5) {
    status.textContent = "Timing 1.5 se 5 second ke beech hona chahiye.";
    return;
  }
  
  status.textContent = "Sending request to backend...";
  
  fetch('http://localhost:3000/bomb-sms', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        mobile: mobile,
        quantity: quantity,
        timing: timing
      })
    })
    .then(res => res.json())
    .then(data => {
      status.textContent = data.message || "Request sent successfully!";
    })
    .catch(err => {
      console.error(err);
      status.textContent = "Error sending request.";
    });
}